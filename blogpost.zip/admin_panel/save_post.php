<?php
include('config.php');

if(isset($_POST) && !empty($_POST)){


	if($_POST['Submit']=='Update'){
		$_SESSION['author']=1;
		$sql = "UPDATE `posts` SET `post` = '".$_POST['post']."' WHERE `posts`.`id` =".$_POST['post_id']; 
		if(mysqli_query($con,$sql)){
			header('location:listing.php');
		}  
	}else if($_POST['Submit']=='Save'){
		$_SESSION['author']=1;
		$sql = "INSERT INTO posts(`post`, `author_id`,`date`)
			VALUES ('".$_POST['post']."','".$_SESSION['author']."',now())";
		if(mysqli_query($con,$sql)){
			header('location:listing.php');
		} 
	}else if($_POST['Submit']=='Profile'){
		$sql="UPDATE `user` SET `bio` = '".$_POST['bio']."',`name` = '".$_POST['name']."'";
		if(!empty($_FILES)){
			$uploadfile='';
			$uploaddir='image/';
			
			  $uploadfile = $uploaddir . basename($_FILES['pictue']['name']);
			try{
				if (move_uploaded_file($_FILES['pictue']['tmp_name'], $uploadfile)){
					
				}
			}catch(Exception $e){
				
			}
			$sql.= ", `picture` = '".$uploadfile."'";
				
		}
	
		if(mysqli_query($con,$sql)){
			header('location:listing.php');
		}
	}
 }   



?> 