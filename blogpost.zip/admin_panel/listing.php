<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<?php include('config.php'); 



$sql="select * from posts";
$result=mysqli_query($con,$sql);









?>

<div class="container">
    <div class="row">

        <div class="col-md-6">
            <div class="panel panel-primary">

                <div class="panel-heading">
                      <a class="btn btn-default" href="addpost.php">Add New Post</a>
                      <a class="btn btn-default" href="profile.php">Update Profile</a>
                      <a class="btn btn-default" href="index.php">Logout</a>
 
                    <div class="pull-right action-buttons">
                        <div class="btn-group pull-right">
                       
                            <ul class="dropdown-menu slidedown">
                                <li><a href="http://www.jquery2dotnet.com"><span class="glyphicon glyphicon-pencil"></span>Edit</a></li>
                                <li><a href="http://www.jquery2dotnet.com"><span class="glyphicon glyphicon-trash"></span>Delete</a></li>
                                <li><a href="http://www.jquery2dotnet.com"><span class="glyphicon glyphicon-flag"></span>Flag</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                      <table class="list-group" border="1" width="100%">
                            <tr >
                            <th>S.No.</th>
                            <th>Post</th>
                            <th  >Action</th>
                       </tr> 
                       <?php $count=1;
                       while($row=mysqli_fetch_assoc($result)) {?>

                                <tr>
                                    <td> <?php echo $count++; ?></td>
                                    <td> <?php echo $row['post']; ?></td>
                                    <td>   <a href="<?php echo 'edit_post.php?id='.$row['id']; ?>"><span class="glyphicon glyphicon-pencil" ></span></a>
                                <a href="<?php echo 'delete_post.php?id='.$row['id']; ?>" class="trash" ><span class="glyphicon glyphicon-trash"></span></a></td>
                                </tr>
                              



                        <?php   }?>        
                  
</table>
                </div>
        
            </div>
        </div>
    </div>
</div>
