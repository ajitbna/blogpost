<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<?php include('config.php'); 



$sql="select * from posts where id=".$_GET['id'];
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);




?>
<div class="container">
  <h2>Create Post</h2>
  <form action="save_post.php" method="POST">
    <input type="hidden" name="post_id" value="<?php echo $row['id']; ?>">
   <div> <textarea name="post" rows="4" cols="50" value="<?php echo $row['post']; ?>">
<?php echo $row['post']; ?>
</textarea> 
</div>
  <div>  <button type="submit" name="Submit" class="btn btn-default" value="Update">Submit</button>

      <a class="btn btn-default" href="listing.php">Cancel</a></div>
  </form>
</div>

</body>
</html>
