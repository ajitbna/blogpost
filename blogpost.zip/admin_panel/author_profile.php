<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<?php include('config.php'); 



$sql="select * from user where id=".$_GET['id'];
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);




?>
<div class="container">
  <h2>Author Profile</h2>
  <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
 

   <div> <span>Author Name: </span><span><?php echo $row['name']; ?></span>
   </div>
     
      <div>

      <?php if($row['picture']!=''){ ?>
        <span>Prifle Picture : </span>
        <div>
      	 <img width="15%" src="<?php echo $row['picture']; ?>"></div>
     <?php  }?>   </div>
       <div>   <span>Prifle Picture : </span>
   <span><?php echo $row['bio']; ?> </span>
 </div>

</div>

</body>
</html>
