<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<?php include('config.php'); 



$sql="select * from posts join user on user.id=posts.author_id order by posts.date desc";
$result=mysqli_query($con,$sql);









?>

<div class="container"><h1>
Author Post</h1>    <div class="row">

        <div class="col-md-6">
            <div class="panel panel-primary">

                <div class="panel-body">
                      <table class="list-group" border="1" width="100%">
                            <tr >
                            <th>S.No.</th>
                            <th>Post</th>
                            <th>Created By </th>
                            <th>Author Picuture</th>
                      
                       </tr> 
                       <?php $count=1;
                       while($row=mysqli_fetch_assoc($result)) {

                        ?>

                                <tr>
                                    <td> <?php echo $count++; ?></td>
                                    <td> <?php echo $row['post']; ?></td>
                                    <td> <a href="<?php echo 'author_profile.php?id='.$row['author_id']; ?>"><?php echo $row['name']; ?></a></td>
                                    <td > <a href="<?php echo 'author_profile.php?id='.$row['author_id']; ?>"><img width="15%"src="<?php echo $row['picture']; ?>"> </a></td>
                                    
                                </tr>
                              



                        <?php   }?>        
                  
</table>
                </div>
        
            </div>
        </div>
    </div>
</div>
