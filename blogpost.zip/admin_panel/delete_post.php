
<?php include('config.php'); 



$sql="delete from posts where id=".$_GET['id'];
$result=mysqli_query($con,$sql);
header('location:listing.php');


?>