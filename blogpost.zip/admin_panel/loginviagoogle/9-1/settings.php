<?php

/* Google App Client Id */
define('CLIENT_ID', '126861146767-smiankf5b8nqhc3fcpprtio570821kmu.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'AIzaSyCv9muSpIMMFO2X24vCikNpQTDn_ZKbJhw');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'https://bmyraahi.com');
//define('CLIENT_REDIRECT_URL', 'http://localhost/admin_panel/');

?>