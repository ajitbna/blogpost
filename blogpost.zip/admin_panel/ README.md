1. to run this task ,you have to import blogs.sql into db.
2. I have created a login page inthat we can login by any simple username or password after logged in we can create/update/delete post/ and logout
3. on login screen there is a link called "View Author Post" by this we can see all post of auther. 