<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Create Post</h2>
  <form action="save_post.php" method="POST">
    <div><textarea name= "post" rows="4" cols="50">

</textarea> </div>
  <div> <button type="submit" name="Submit" class="btn btn-default" value="Save">Submit</button>
 
      <a class="btn btn-default" href="listing.php">Cancel</a>
 </div>
  </form>
</div>

</body>
</html>
