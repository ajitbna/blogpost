<?php 


unset($_SESSION);
header('location:login.php');

?>